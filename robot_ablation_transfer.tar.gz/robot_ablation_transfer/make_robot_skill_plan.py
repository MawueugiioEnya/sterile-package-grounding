#!/usr/bin/env python3
"""
Create a robot-skill plan from one grounding method/sequence.

This does not command YuMi and does not generate robot coordinates.
It converts semantic grounding events into a common downstream skill plan.

Example:
  python scripts/make_robot_skill_plan.py \
    --cohort ../matched_grounding_cohort.json \
    --sequence P01_SEQ_0003 \
    --method hybrid \
    --out ../robot_skill_plans/P01_SEQ_0003_hybrid.json
"""

import argparse
import json
from pathlib import Path

EVENT_TO_SKILL = {
    "grasp_flaps": "ACQUIRE_AND_PICK",
    "peel_apart": "OPPOSED_OPEN",
    "drop_contents": "RELEASE",
}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cohort", required=True)
    ap.add_argument("--sequence", required=True)
    ap.add_argument(
        "--method",
        required=True,
        choices=["geometry_motion", "pixtral_only", "hybrid"],
    )
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    cohort = json.loads(Path(args.cohort).read_text())

    record = next(
        (x for x in cohort["sequences"] if x["sequence"] == args.sequence),
        None,
    )
    if record is None:
        raise SystemExit(f"Sequence not found: {args.sequence}")

    events = record["methods"][args.method]

    skills = []
    for event in ("grasp_flaps", "peel_apart", "drop_contents"):
        frame = events.get(event)

        if frame is None:
            skills.append({
                "event": event,
                "source_frame": None,
                "skill": EVENT_TO_SKILL[event],
                "available": False,
            })
        else:
            skills.append({
                "event": event,
                "source_frame": int(frame),
                "skill": EVENT_TO_SKILL[event],
                "available": True,
            })

    # Execution is valid only up to the first missing semantic event.
    executable = []
    blocked = False
    for item in skills:
        if blocked or not item["available"]:
            blocked = True
            executable.append({
                **item,
                "execute": False,
            })
        else:
            executable.append({
                **item,
                "execute": True,
            })

    output = {
        "sequence": args.sequence,
        "grounding_method": args.method,
        "skill_plan": executable,
        "notes": {
            "source_frame_is_semantic_reference_only": True,
            "robot_coordinates_must_come_from_live_robot_perception": True,
            "manual_preseparation_is_not_a_robot_skill": True,
        },
    }

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(output, indent=2) + "\n")

    print(f"Saved: {out}")
    print()
    for item in executable:
        print(
            f"{item['event']:14s} -> {item['skill']:16s} "
            f"frame={str(item['source_frame']):>4s} "
            f"execute={item['execute']}"
        )

if __name__ == "__main__":
    main()
