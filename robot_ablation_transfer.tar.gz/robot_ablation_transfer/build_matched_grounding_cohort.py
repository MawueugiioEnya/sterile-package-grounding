#!/usr/bin/env python3
import argparse
import json
from pathlib import Path

METHODS = ("geometry_motion", "pixtral_only", "hybrid")
EVENTS = ("grasp_flaps", "peel_apart", "drop_contents")

def load_json(path):
    with path.open("r") as f:
        return json.load(f)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--exports_dir", required=True)
    ap.add_argument("--out", default="matched_grounding_cohort.json")
    args = ap.parse_args()

    root = Path(args.exports_dir)
    pixtral_dir = root / "pixtral_only"

    pixtral_files = sorted(pixtral_dir.glob("*.json"))
    if not pixtral_files:
        raise SystemExit(f"No Pixtral-only JSON files found in {pixtral_dir}")

    matched = []

    for pf in pixtral_files:
        seq = pf.stem
        item = {
            "sequence": seq,
            "methods": {}
        }

        for method in METHODS:
            path = root / method / f"{seq}.json"
            if not path.exists():
                raise SystemExit(f"Missing {method} file for {seq}: {path}")

            d = load_json(path)
            events = d.get("events", {})
            item["methods"][method] = {
                event: events.get(event)
                for event in EVENTS
            }

        matched.append(item)

    output = {
        "cohort": "pixtral_matched_24",
        "n_sequences": len(matched),
        "methods": list(METHODS),
        "events": list(EVENTS),
        "sequences": matched,
    }

    out = Path(args.out)
    out.write_text(json.dumps(output, indent=2) + "\n")

    print(f"Wrote {len(matched)} matched sequences to {out}")

    missing = {
        method: {event: 0 for event in EVENTS}
        for method in METHODS
    }

    for item in matched:
        for method in METHODS:
            for event in EVENTS:
                if item["methods"][method][event] is None:
                    missing[method][event] += 1

    for method in METHODS:
        print(method)
        for event in EVENTS:
            print(f"  {event}: missing {missing[method][event]}")

if __name__ == "__main__":
    main()
